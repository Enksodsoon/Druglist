#!/usr/bin/env python3
import argparse
import hashlib
import json
import mimetypes
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse
import pandas as pd
import requests
from tqdm import tqdm

SKIP_METHODS = {"manual_review"}
USER_AGENT = "DruglistEvidenceDownloader/1.0 (+manual evidence cache; contact: local user)"


def safe_name(value: str, max_len=100):
    import re
    value = str(value or "source").strip()
    value = re.sub(r"[^A-Za-z0-9ก-๙._-]+", "_", value)
    return value[:max_len].strip("._-") or "source"


def ext_from_response(url, response):
    path_ext = Path(urlparse(url).path).suffix
    if path_ext:
        return path_ext[:10]
    ctype = response.headers.get("content-type", "").split(";")[0].strip().lower()
    return mimetypes.guess_extension(ctype) or ".html"


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--queue", required=True)
    parser.add_argument("--limit", type=int, default=0, help="0 = no limit")
    parser.add_argument("--timeout", type=int, default=30)
    args = parser.parse_args()

    df = pd.read_csv(args.queue).fillna("")
    rows = df.to_dict("records")
    if args.limit:
        rows = rows[:args.limit]

    results = []
    session = requests.Session()
    session.headers.update({"User-Agent": USER_AGENT})

    for row in tqdm(rows, desc="Downloading"):
        method = row.get("method", "")
        result = dict(row)
        if method in SKIP_METHODS:
            result.update({"status": "skipped_manual", "local_path": "", "sha256": ""})
            results.append(result)
            continue

        url = row.get("url")
        cache_dir = Path(row.get("cache_dir") or "imports/accepted_evidence/bulk")
        cache_dir.mkdir(parents=True, exist_ok=True)
        try:
            resp = session.get(url, timeout=args.timeout, allow_redirects=True)
            resp.raise_for_status()
            ext = ext_from_response(url, resp)
            fname = f"{safe_name(row.get('task_id'))}_{safe_name(row.get('record_id'))}{ext}"
            path = cache_dir / fname
            path.write_bytes(resp.content)
            sha = sha256_bytes(resp.content)

            meta = {
                "source_id": row.get("record_id"),
                "task_id": row.get("task_id"),
                "source_url": url,
                "local_path": str(path),
                "sha256": sha,
                "downloaded_at": datetime.now(timezone.utc).isoformat(),
                "http_status": resp.status_code,
                "content_type": resp.headers.get("content-type", ""),
                "method": method,
                "notes": "Auto-downloaded. Review content before using for Gold verification."
            }
            (path.with_suffix(path.suffix + ".meta.json")).write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
            result.update({"status": "downloaded", "local_path": str(path), "sha256": sha, "notes": ""})
        except Exception as e:
            result.update({"status": "failed", "local_path": "", "sha256": "", "notes": str(e)[:500]})
        results.append(result)

    out = Path("reports/source_download_results.csv")
    out.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(results).to_csv(out, index=False)
    print(f"Wrote: {out}")

if __name__ == "__main__":
    main()
