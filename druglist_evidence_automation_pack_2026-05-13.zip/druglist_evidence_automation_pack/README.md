# Druglist Evidence Automation Pack

This pack turns the download-link workbook into a semi-automated evidence pipeline.

## Goal

Reduce manual work from **910 product-by-product checks** into:

1. bulk source download,
2. generic/drug-level label matching,
3. disease-bundle guideline extraction,
4. manual review only for failed/high-risk rows,
5. Codex-ready evidence batches.

## Fastest workflow

Put this pack at the root of your repo:

```text
Druglist/
  druglist_all_download_links_2026-05-13.xlsx
  scripts/
  prompts/
  schemas/
  imports/accepted_evidence/
```

Then run:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

python scripts/00_setup_folders.py
python scripts/01_build_source_queue.py --links-xlsx druglist_all_download_links_2026-05-13.xlsx
python scripts/02_download_http_sources.py --queue reports/source_download_queue.csv
python scripts/03_dailymed_resolver.py --links-xlsx druglist_all_download_links_2026-05-13.xlsx
python scripts/04_build_manifest.py --root imports/accepted_evidence
python scripts/05_prepare_chatgpt_batches.py --links-xlsx druglist_all_download_links_2026-05-13.xlsx --batch-size 25
```

## What still needs human review

Do not fully automate these without review:

- antibiotic RX NOW/SWAPS unlock,
- pediatric exact dose calculators,
- pregnancy/lactation safety,
- renal/hepatic contraindication decisions,
- Thai brand-only products without official label match,
- steroid/NSAID/fluoroquinolone/antibiotic high-risk use.

## Best order

1. Download all bulk label sources.
2. Resolve 79 generic drug labels first.
3. Map products to generic labels instead of searching all 910 manually.
4. Download disease bundle guidelines for common OPD first.
5. Extract high-frequency RX NOW/SWAPS rows.
6. Review antibiotics and pediatrics separately.

## Output folders

```text
imports/accepted_evidence/
  bulk/
  disease/<disease_key>/
  drug/<generic_slug>/
  product/<product_code_or_slug>/
  manifest/

reports/
  source_download_queue.csv
  source_download_results.csv
  manual_download_todo.csv
  dailymed_candidates.csv
  evidence_manifest.jsonl

batches/
  batch_001/
    task_list.csv
    prompt.md
```
